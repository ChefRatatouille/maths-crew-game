export type MathTask = {
  id: number;
  room: string;
  roomIndex: number;
  type: "wires" | "cctv" | "upload" | "power";
  title: string;
  equation: string;
  answer: string;
  choices: string[];
  partials: string[];
  hint: string;
  steps: string;
};

export const MATH_TASKS: MathTask[] = [
  { id: 0, room: "ORBITAL LAB", roomIndex: 0, type: "wires", title: "Connect the answer wires", equation: "(x + 2)(x + 3)", answer: "x² + 5x + 6", choices: ["x² + 5x + 6", "x² + 6x + 5", "x² + 5x + 5", "x² + 6x + 6"], partials: ["x²", "3x", "2x", "6"], hint: "Multiply every term in the first bracket by every term in the second.", steps: "x·x + x·3 + 2·x + 2·3 = x² + 3x + 2x + 6 = x² + 5x + 6." },
  { id: 1, room: "SIGNAL NEST", roomIndex: 1, type: "cctv", title: "Restore the CCTV feed", equation: "(x + 5)(x − 2)", answer: "x² + 3x − 10", choices: ["x² + 3x − 10", "x² − 3x − 10", "x² + 7x − 10", "x² + 3x + 10"], partials: ["x²", "−2x", "5x", "−10"], hint: "The cross terms are −2x and +5x. The constant is 5·(−2).", steps: "x² − 2x + 5x − 10 = x² + 3x − 10." },
  { id: 2, room: "BIO DOME", roomIndex: 2, type: "upload", title: "Upload the growth formula", equation: "(2x + 1)(x + 3)", answer: "2x² + 7x + 3", choices: ["2x² + 7x + 3", "2x² + 6x + 3", "2x² + 5x + 3", "2x² + 7x + 4"], partials: ["2x²", "6x", "x", "3"], hint: "The cross terms are 6x and x. Add them after multiplying.", steps: "2x² + 6x + x + 3 = 2x² + 7x + 3." },
  { id: 3, room: "ASTRA LENS", roomIndex: 3, type: "power", title: "Align the lens power", equation: "(x − 4)(x − 2)", answer: "x² − 6x + 8", choices: ["x² − 6x + 8", "x² + 6x + 8", "x² − 2x + 8", "x² − 6x − 8"], partials: ["x²", "−2x", "−4x", "8"], hint: "The cross terms are −2x and −4x. Two negative constants multiply to a positive.", steps: "x² − 2x − 4x + 8 = x² − 6x + 8." },
  { id: 4, room: "ARCHIVE", roomIndex: 4, type: "wires", title: "Patch the archive wires", equation: "(3x + 2)(x + 1)", answer: "3x² + 5x + 2", choices: ["3x² + 5x + 2", "3x² + 3x + 2", "3x² + 5x + 1", "3x² + 2x + 2"], partials: ["3x²", "3x", "2x", "2"], hint: "The cross terms are 3x and 2x.", steps: "3x² + 3x + 2x + 2 = 3x² + 5x + 2." },
  { id: 5, room: "CREW GALLEY", roomIndex: 5, type: "cctv", title: "Clear the galley camera", equation: "(x + 6)(x + 6)", answer: "x² + 12x + 36", choices: ["x² + 12x + 36", "x² + 6x + 36", "x² + 12x + 12", "x² + 36"], partials: ["x²", "6x", "6x", "36"], hint: "The cross terms are both 6x. Add them together.", steps: "x² + 6x + 6x + 36 = x² + 12x + 36." },
  { id: 6, room: "POWER CORE", roomIndex: 6, type: "upload", title: "Upload the core sequence", equation: "(2x − 3)(x + 4)", answer: "2x² + 5x − 12", choices: ["2x² + 5x − 12", "2x² + 11x − 12", "2x² + 5x + 12", "2x² − 5x − 12"], partials: ["2x²", "8x", "−3x", "−12"], hint: "The cross terms are 8x and −3x. The constant is −12.", steps: "2x² + 8x − 3x − 12 = 2x² + 5x − 12." },
  { id: 7, room: "FABRICATOR", roomIndex: 7, type: "power", title: "Calibrate the fabricator", equation: "(x − 7)(x + 1)", answer: "x² − 6x − 7", choices: ["x² − 6x − 7", "x² + 6x − 7", "x² − 7x + 1", "x² − 6x + 7"], partials: ["x²", "x", "−7x", "−7"], hint: "The cross terms are +x and −7x.", steps: "x² + x − 7x − 7 = x² − 6x − 7." },
  { id: 8, room: "MED BAY", roomIndex: 8, type: "wires", title: "Reconnect the scanner", equation: "(3x − 2)(x − 3)", answer: "3x² − 11x + 6", choices: ["3x² − 11x + 6", "3x² − 9x + 6", "3x² + 11x + 6", "3x² − 11x − 6"], partials: ["3x²", "−9x", "−2x", "6"], hint: "The cross terms are −9x and −2x.", steps: "3x² − 9x − 2x + 6 = 3x² − 11x + 6." },
  { id: 9, room: "CARGO HOLD", roomIndex: 9, type: "cctv", title: "Check the cargo cameras", equation: "2x(x − 5)", answer: "2x² − 10x", choices: ["2x² − 10x", "2x² − 5x", "2x − 10", "2x² + 10x"], partials: ["2x²", "−10x"], hint: "Distribute 2x to both terms. 2x multiplied by −5 gives −10x.", steps: "2x·x + 2x·(−5) = 2x² − 10x." },
  { id: 10, room: "AQUA WORKS", roomIndex: 10, type: "upload", title: "Upload the pump formula", equation: "(2x + 5)(2x − 5)", answer: "4x² − 25", choices: ["4x² − 25", "4x² + 25", "4x² − 20x − 25", "4x² − 10"], partials: ["4x²", "−10x", "10x", "−25"], hint: "The middle terms cancel: −10x + 10x = 0.", steps: "4x² − 10x + 10x − 25 = 4x² − 25." },
  { id: 11, room: "OBSERVATORY", roomIndex: 11, type: "power", title: "Set the observatory focus", equation: "2x(x + 4)", answer: "2x² + 8x", choices: ["2x² + 8x", "2x² + 4x", "2x + 8", "2x² + 8"], partials: ["2x²", "8x"], hint: "Multiply 2x by x, then multiply 2x by 4.", steps: "2x·x + 2x·4 = 2x² + 8x." },
  { id: 12, room: "ENGINE BAY", roomIndex: 12, type: "wires", title: "Reconnect the engine coils", equation: "(x + 2)(x² + x + 1)", answer: "x³ + 3x² + 3x + 2", choices: ["x³ + 3x² + 3x + 2", "x³ + 2x² + 3x + 2", "x³ + 3x² + 2x + 2", "x³ + 3x² + 3x + 1"], partials: ["x³", "x²", "x", "2x²", "2x", "2"], hint: "First get x³ + x² + x. Then add 2x² + 2x + 2.", steps: "x³ + x² + x + 2x² + 2x + 2 = x³ + 3x² + 3x + 2." },
  { id: 13, room: "LAUNCH DECK", roomIndex: 13, type: "power", title: "Restart the launch gate", equation: "(2x − 1)(x² + 2x + 3)", answer: "2x³ + 3x² + 4x − 3", choices: ["2x³ + 3x² + 4x − 3", "2x³ + 5x² + 4x − 3", "2x³ + 3x² + 6x − 3", "2x³ + 3x² + 4x + 3"], partials: ["2x³", "4x²", "6x", "−x²", "−2x", "−3"], hint: "Distribute 2x first: 2x³ + 4x² + 6x. Then subtract x² + 2x + 3.", steps: "2x³ + 4x² + 6x − x² − 2x − 3 = 2x³ + 3x² + 4x − 3." },
];

export const ATTACK_QUESTIONS = [2, 4, 8, 11, 12, 13].map((id) => MATH_TASKS[id]);
