import { and, eq } from "drizzle-orm";
import { getDb } from "../db";
import { gameRooms } from "../db/schema";
import { ATTACK_QUESTIONS, MATH_TASKS } from "./math";

export type Player = { id: string; name: string; color: number; role: "crew" | "impostor"; alive: boolean; x: number; y: number };
export type RoomState = {
  code: string;
  hostId: string;
  phase: "lobby" | "playing" | "crew-win" | "impostor-win";
  winner: string | null;
  createdAt: number;
  settings: { impostors: number; attackWindow: number; map: string };
  players: Player[];
  completedTasks: number[];
  attack: null | { playerId: string; questionIds: number[]; progress: number; deadline: number; ready: boolean };
  events: { id: string; text: string; at: number }[];
};

export class RoomError extends Error {
  status: number;
  constructor(message: string, status = 400) { super(message); this.status = status; }
}

const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function makeCode() {
  const bytes = crypto.getRandomValues(new Uint8Array(6));
  return Array.from(bytes, (n) => alphabet[n % alphabet.length]).join("");
}
function failWinner(state: RoomState) {
  if (state.phase !== "playing") return;
  const impostors = state.players.filter((p) => p.alive && p.role === "impostor").length;
  const crew = state.players.filter((p) => p.alive && p.role === "crew").length;
  if (!impostors) { state.phase = "crew-win"; state.winner = "Crew"; }
  else if (!crew || impostors >= crew) { state.phase = "impostor-win"; state.winner = "Impostors"; }
  else if (state.completedTasks.length === MATH_TASKS.length) { state.phase = "crew-win"; state.winner = "Crew"; }
}
function event(state: RoomState, text: string) {
  state.events = [...state.events.slice(-7), { id: crypto.randomUUID(), text, at: Date.now() }];
}

export async function readRoom(code: string): Promise<RoomState> {
  const db = getDb();
  const row = await db.select().from(gameRooms).where(eq(gameRooms.code, code.toUpperCase())).get();
  if (!row) throw new RoomError("Room code not found.", 404);
  const state = JSON.parse(row.stateJson) as RoomState;
  if (state.attack && Date.now() > state.attack.deadline) {
    const player = state.players.find((p) => p.id === state.attack?.playerId);
    if (player?.alive) { player.alive = false; event(state, `${player.name} failed the three-question attack challenge and was ejected.`); }
    state.attack = null;
    failWinner(state);
    await writeRoom(code.toUpperCase(), row.revision, state);
  }
  return state;
}

export async function writeRoom(code: string, expectedRevision: number, state: RoomState) {
  const db = getDb();
  const result = await db.update(gameRooms).set({ stateJson: JSON.stringify(state), revision: expectedRevision + 1, updatedAt: Date.now() })
    .where(and(eq(gameRooms.code, code), eq(gameRooms.revision, expectedRevision))).returning({ code: gameRooms.code });
  if (!result.length) throw new RoomError("The room changed on another device. Refreshing…", 409);
  return state;
}

export async function changeRoom(code: string, action: (state: RoomState) => void | Promise<void>) {
  const normalized = code.toUpperCase();
  for (let attempt = 0; attempt < 4; attempt++) {
    const db = getDb();
    const row = await db.select().from(gameRooms).where(eq(gameRooms.code, normalized)).get();
    if (!row) throw new RoomError("Room code not found.", 404);
    const state = JSON.parse(row.stateJson) as RoomState;
    if (state.attack && Date.now() > state.attack.deadline) {
      const player = state.players.find((p) => p.id === state.attack?.playerId);
      if (player?.alive) { player.alive = false; event(state, `${player.name} ran out of time and was ejected.`); }
      state.attack = null; failWinner(state);
    }
    await action(state);
    try { return await writeRoom(normalized, row.revision, state); }
    catch (error) { if (!(error instanceof RoomError) || error.status !== 409 || attempt === 3) throw error; }
  }
  throw new RoomError("Could not update the room. Try again.", 409);
}

export async function createRoom(input: { id: string; name: string; impostors: number; attackWindow: number; map: string }) {
  const db = getDb();
  const impostors = Math.max(1, Math.min(3, Math.floor(input.impostors || 1)));
  const attackWindow = Math.max(30, Math.min(120, Math.floor(input.attackWindow || 60)));
  for (let attempt = 0; attempt < 5; attempt++) {
    const code = makeCode();
    const state: RoomState = {
      code, hostId: input.id, phase: "lobby", winner: null, createdAt: Date.now(),
      settings: { impostors, attackWindow, map: input.map || "The Arc" },
      players: [{ id: input.id, name: input.name.slice(0, 16) || "Crewmate", color: 0, role: "crew", alive: true, x: 600, y: 345 }],
      completedTasks: [], attack: null, events: [{ id: crypto.randomUUID(), text: "Room created. Share the code to invite crew.", at: Date.now() }],
    };
    try { await db.insert(gameRooms).values({ code, stateJson: JSON.stringify(state), revision: 0, updatedAt: Date.now() }); return state; }
    catch (error) { if (attempt === 4) throw error; }
  }
  throw new RoomError("Could not create a room. Try again.", 500);
}

export async function applyRoomAction(state: RoomState, playerId: string, body: Record<string, unknown>) {
  const action = String(body.action || "");
  if (action === "join") {
    if (state.phase !== "lobby") throw new RoomError("This game has already started.", 409);
    if (state.players.some((p) => p.id === playerId)) return;
    if (state.players.length >= 10) throw new RoomError("This room is full.", 409);
    const colors = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
    const color = colors.find((c) => !state.players.some((p) => p.color === c)) ?? 0;
    state.players.push({ id: playerId, name: String(body.name || "Crewmate").slice(0, 16), color, role: "crew", alive: true, x: 600 + state.players.length * 18, y: 345 });
    event(state, `${state.players[state.players.length - 1].name} joined the crew.`);
    return;
  }
  const player = state.players.find((p) => p.id === playerId);
  if (!player) throw new RoomError("Player is no longer in this room.", 403);
  if (action === "settings") {
    if (state.phase !== "lobby" || state.hostId !== playerId) throw new RoomError("Only the host can change lobby settings.", 403);
    const impostors = Math.max(1, Math.min(3, Math.floor(Number(body.impostors) || 1)));
    const attackWindow = Math.max(30, Math.min(120, Math.floor(Number(body.attackWindow) || 60)));
    if (impostors >= state.players.length) throw new RoomError("Add at least one more player than impostors.");
    state.settings.impostors = impostors; state.settings.attackWindow = attackWindow; event(state, "Host updated the match settings."); return;
  }
  if (action === "start") {
    if (state.hostId !== playerId || state.phase !== "lobby") throw new RoomError("Only the host can start the match.", 403);
    if (state.players.length < state.settings.impostors + 2) throw new RoomError(`Add at least ${state.settings.impostors + 2} players for this impostor setting.`);
    const order = [...state.players];
    for (let i = order.length - 1; i > 0; i--) { const j = crypto.getRandomValues(new Uint32Array(1))[0] % (i + 1); [order[i], order[j]] = [order[j], order[i]]; }
    const impostorIds = new Set(order.slice(0, state.settings.impostors).map((p) => p.id));
    state.players.forEach((p) => { p.role = impostorIds.has(p.id) ? "impostor" : "crew"; });
    state.phase = "playing"; event(state, "The match has started. Finish your maths tasks."); return;
  }
  if (action === "move") {
    if (state.phase !== "playing" || !player.alive) return;
    const x = Number(body.x), y = Number(body.y);
    if (Number.isFinite(x) && Number.isFinite(y) && Math.abs(x - player.x) < 80 && Math.abs(y - player.y) < 80) { player.x = x; player.y = y; }
    return;
  }
  if (action === "task") {
    if (state.phase !== "playing" || !player.alive || player.role !== "crew") throw new RoomError("Only living crewmates can complete crew tasks.", 403);
    const id = Math.floor(Number(body.taskId));
    const task = MATH_TASKS[id];
    if (!task || body.answer !== task.answer) throw new RoomError("That polynomial answer is not correct.");
    if (!state.completedTasks.includes(id)) { state.completedTasks.push(id); event(state, `${player.name} restored ${task.room}.`); }
    failWinner(state); return;
  }
  if (action === "begin-attack") {
    if (state.phase !== "playing" || !player.alive || player.role !== "impostor") throw new RoomError("Only a living impostor can start an attack challenge.", 403);
    if (state.attack) throw new RoomError("Another impostor is already solving an attack challenge.", 409);
    const pool = [...ATTACK_QUESTIONS];
    const questionIds: number[] = [];
    while (questionIds.length < 3) { const pick = pool.splice(crypto.getRandomValues(new Uint32Array(1))[0] % pool.length, 1)[0]; questionIds.push(pick.id); }
    state.attack = { playerId, questionIds, progress: 0, deadline: Date.now() + state.settings.attackWindow * 1000, ready: false };
    event(state, `${player.name} is attempting a timed attack challenge.`); return;
  }
  if (action === "attack-answer") {
    if (!state.attack || state.attack.playerId !== playerId || state.attack.ready) throw new RoomError("No active attack question for this player.", 409);
    const task = MATH_TASKS[state.attack.questionIds[state.attack.progress]];
    if (!task || body.answer !== task.answer) {
      player.alive = false; state.attack = null; event(state, `${player.name} missed an equation and was ejected.`); failWinner(state); return;
    }
    state.attack.progress++;
    if (state.attack.progress >= 3) { state.attack.ready = true; event(state, `${player.name} solved three equations and can tag a crewmate.`); }
    return;
  }
  if (action === "tag") {
    if (!state.attack || state.attack.playerId !== playerId || !state.attack.ready || player.role !== "impostor") throw new RoomError("Solve all three equations before tagging.", 403);
    const target = state.players.find((p) => p.id === body.targetId);
    if (!target || !target.alive || target.role !== "crew") throw new RoomError("Choose a living crewmate.");
    target.alive = false; state.attack = null; event(state, `${target.name} was tagged and is out of the match.`); failWinner(state); return;
  }
  if (action === "leave") {
    player.alive = false; state.players = state.players.filter((p) => p.id !== playerId); if (state.hostId === playerId) state.hostId = state.players[0]?.id || ""; event(state, `${player.name} left the room.`); failWinner(state); return;
  }
  throw new RoomError("Unknown room action.");
}
