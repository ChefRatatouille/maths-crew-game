# PolyCrew

PolyCrew is a small browser game for practising Chapter 6, **Multiplication of Polynomial**, from *Maths Olympiad: Unleash the Maths Olympian in You! The Next Lap* (ages 12–14). The chapter picker lists the book's 22 chapters, but only Chapter 6 is enabled until source pages for other chapters are provided. This avoids presenting unverified material as book-aligned.

Choose **Learn** for a short, worked walkthrough before each station, or **Revise** to attempt it first and reveal a hint or full working when needed. Solo play includes 14 polynomial challenges, movement around an original ship map, a task list, and a mission-complete screen. Online rooms use six-character codes; the host can set one to three impostors and a shared 30–120 second challenge window. Impostors must solve three questions within that window before tagging a crewmate. The server validates submitted answers and withholds hidden roles from other players.

## Run locally

This project uses Vinext, Vite and Cloudflare D1. It requires Node.js 22.13 or later.

```sh
npm install
npm run db:generate
npm run build
```

The online room endpoints need a Cloudflare D1 database bound as `DB`. The schema is in `db/schema.ts`; the generated SQL migration is in `drizzle/`. Local solo mode can be explored without a database. To run the built app with the Cloudflare worker locally, configure the D1 binding and use `npm start`.

## Project layout

- `app/play.tsx` — home, lobby, map, tasks and game UI
- `lib/math.ts` — original Chapter 6 question set, choices and worked solutions
- `lib/rooms.ts` — multiplayer room state and server-side answer checks
- `app/api/rooms/` — room creation, joining and game actions
- `db/` and `drizzle/` — D1 schema and migration

The visual design and map are original and use no game-brand artwork. Mathematical questions and explanations are written for this project; no book pages or answer key are reproduced.
