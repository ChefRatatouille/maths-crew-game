"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MATH_TASKS, type MathTask } from "../lib/math";

type Mode = "learn" | "revise";
type Screen = "home" | "lobby" | "game";
type Player = { id: string; name: string; color: number; role: "crew" | "impostor" | "unknown"; alive: boolean; x: number; y: number };
type OnlineRoom = { code: string; hostId: string; phase: string; winner: string | null; settings: { impostors: number; attackWindow: number; map: string }; players: Player[]; completedTasks: number[]; attack: null | { playerId: string; progress: number; ready: boolean; deadline: number; questionIds?: number[] }; events: { id: string; text: string; at: number }[] };

const chapters = ["Simple Equation", "Absolute Value", "Operation of Rational Numbers", "Operation of Indices", "Simultaneous Equations", "Multiplication of Polynomial", "Divisibility", "Prime and Composite Numbers", "Square Number", "Even and Odd Numbers", "GCD and LCM", "Permutation and Combination", "Observation and Induction", "Other Operations", "Numbering System", "Basics of Probability", "Lines and Angles", "Triangles", "Pythagorean Theorem", "Profit and Loss", "Area", "Pigeonhole Principle"];
const colors = ["#ff5f57", "#46c7ec", "#64ce67", "#f6a83f", "#a879ed", "#ff81b9", "#f1e667", "#b9d7e5", "#9b6844", "#f1f1f1"];
const freshId = () => typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : Math.random().toString(36).slice(2);

export function CrewGame() {
  const [screen, setScreen] = useState<Screen>("home");
  const [chapter, setChapter] = useState(6);
  const [mode, setMode] = useState<Mode>("learn");
  const [playerName, setPlayerName] = useState("Crewmate");
  const [multiplayer, setMultiplayer] = useState(false);
  const [impostors, setImpostors] = useState(1);
  const [attackWindow, setAttackWindow] = useState(60);
  const [roomCode, setRoomCode] = useState("");
  const [playerId, setPlayerId] = useState("");
  const [room, setRoom] = useState<OnlineRoom | null>(null);
  const [notice, setNotice] = useState("");
  const [completed, setCompleted] = useState<number[]>([]);
  const [activeTask, setActiveTask] = useState<MathTask | null>(null);
  const [lessonStep, setLessonStep] = useState(0);
  const [answerMessage, setAnswerMessage] = useState("");
  const [wrong, setWrong] = useState(false);
  const [playerPos, setPlayerPos] = useState({ x: 50, y: 56 });
  const [attackQuestion, setAttackQuestion] = useState<MathTask | null>(null);
  const [attackRemain, setAttackRemain] = useState(0);
  const [attackProgress, setAttackProgress] = useState(0);
  const [selectedTarget, setSelectedTarget] = useState("");
  const keys = useRef(new Set<string>());
  const timer = useRef<number | null>(null);
  const lastMoveSync = useRef(0);
  const isWin = completed.length === MATH_TASKS.length;
  const selectedPlayer = room?.players.find((p) => p.id === playerId);
  const aliveCrew = room?.players.filter((p) => p.alive && p.role !== "impostor") || [];
  const me = room?.players.find((p) => p.id === playerId);

  const api = useCallback(async (action: string, body: Record<string, unknown> = {}) => {
    if (!room || !playerId) return null;
    const res = await fetch(`/api/rooms/${room.code}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ playerId, action, ...body }) });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Room update failed.");
    setRoom(data.room as OnlineRoom);
    return data.room as OnlineRoom;
  }, [room, playerId]);

  const startSingle = () => {
    setMultiplayer(false); setCompleted([]); setPlayerPos({ x: 50, y: 56 }); setScreen("game"); setActiveTask(null); setNotice("");
  };
  const createRoom = async () => {
    try {
      const id = freshId();
      const res = await fetch("/api/rooms", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, name: playerName, impostors, attackWindow, map: "The Arc" }) });
      const data = await res.json(); if (!res.ok) throw new Error(data.error || "Could not create room.");
      setPlayerId(id); setRoom(data.room); setRoomCode(data.room.code); setMultiplayer(true); setScreen("lobby"); setNotice("");
    } catch (e) { setNotice(e instanceof Error ? e.message : "Could not create room."); }
  };
  const joinRoom = async () => {
    try {
      const id = freshId(); const code = roomCode.trim().toUpperCase();
      const res = await fetch(`/api/rooms/${code}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ playerId: id, action: "join", name: playerName }) });
      const data = await res.json(); if (!res.ok) throw new Error(data.error || "Could not join room.");
      setPlayerId(id); setRoom(data.room); setRoomCode(code); setMultiplayer(true); setScreen(data.room.phase === "lobby" ? "lobby" : "game"); setNotice("");
    } catch (e) { setNotice(e instanceof Error ? e.message : "Could not join room."); }
  };

  useEffect(() => {
    if (!room || !playerId) return;
    const poll = async () => {
      try { const res = await fetch(`/api/rooms/${room.code}?playerId=${encodeURIComponent(playerId)}`, { cache: "no-store" }); const data = await res.json(); if (res.ok) { setRoom(data.room); if (data.room.phase !== "lobby") setScreen("game"); } }
      catch { /* Poll again; mobile connections can drop briefly. */ }
    };
    const id = window.setInterval(poll, 1800); return () => window.clearInterval(id);
  }, [room?.code, playerId]);

  useEffect(() => {
    if (screen !== "game" || activeTask || isWin) return;
    const move = (event: KeyboardEvent) => { const key = event.key.toLowerCase(); if (["arrowup", "arrowdown", "arrowleft", "arrowright", "w", "a", "s", "d"].includes(key)) { event.preventDefault(); keys.current.add(key); } };
    const stop = (event: KeyboardEvent) => keys.current.delete(event.key.toLowerCase());
    const tick = window.setInterval(() => {
      if (!keys.current.size) return;
      setPlayerPos((p) => {
        let x = p.x, y = p.y; const speed = multiplayer ? 0.28 : 1.15;
        if (keys.current.has("arrowup") || keys.current.has("w")) y -= speed;
        if (keys.current.has("arrowdown") || keys.current.has("s")) y += speed;
        if (keys.current.has("arrowleft") || keys.current.has("a")) x -= speed;
        if (keys.current.has("arrowright") || keys.current.has("d")) x += speed;
        const next = { x: Math.max(5, Math.min(95, x)), y: Math.max(8, Math.min(92, y)) };
        if (multiplayer && room?.code && playerId && Date.now() - lastMoveSync.current > 640) {
          lastMoveSync.current = Date.now();
          fetch(`/api/rooms/${room.code}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ playerId, action: "move", x: next.x * 12, y: next.y * 7 }) }).then((response) => response.json()).then((data) => { if (data.room) setRoom(data.room); }).catch(() => {});
        }
        return next;
      });
    }, 32);
    window.addEventListener("keydown", move); window.addEventListener("keyup", stop);
    return () => { window.clearInterval(tick); window.removeEventListener("keydown", move); window.removeEventListener("keyup", stop); };
  }, [screen, multiplayer, activeTask, isWin, room?.code, playerId]);

  useEffect(() => {
    if (!attackQuestion || attackRemain <= 0) return;
    timer.current = window.setTimeout(() => setAttackRemain((t) => t - 1), 1000);
    return () => { if (timer.current) window.clearTimeout(timer.current); };
  }, [attackQuestion, attackRemain]);
  useEffect(() => {
    if (attackQuestion && attackRemain === 0) { setAttackQuestion(null); api("attack-answer", { answer: "__TIMEOUT__" }).catch((e) => setNotice(e.message)); }
  }, [attackRemain, attackQuestion, api]);

  const openTask = (task: MathTask) => { setActiveTask(task); setLessonStep(0); setAnswerMessage(""); setWrong(false); };
  const submitAnswer = async (task: MathTask, answer: string) => {
    if (answer !== task.answer) { setWrong(true); setAnswerMessage("Not quite. Check the signs, then try again."); return; }
    try {
      if (multiplayer) { await api("task", { taskId: task.id, answer }); }
      else setCompleted((list) => list.includes(task.id) ? list : [...list, task.id]);
      setCompleted((list) => list.includes(task.id) ? list : [...list, task.id]); setAnswerMessage("Correct — station restored!"); setWrong(false);
      window.setTimeout(() => setActiveTask(null), 650);
    } catch (e) { setAnswerMessage(e instanceof Error ? e.message : "That answer could not be saved."); }
  };
  const startAttack = async () => {
    try {
      const fresh = await api("begin-attack");
      const ids = fresh?.attack?.questionIds;
      if (ids?.length) { setAttackProgress(0); setAttackRemain(fresh.settings.attackWindow); setAttackQuestion(MATH_TASKS[ids[0]]); }
    } catch (e) { setNotice(e instanceof Error ? e.message : "Could not start challenge."); }
  };
  const answerAttack = async (answer: string) => {
    try {
      const result = await api("attack-answer", { answer });
      const attack = result?.attack;
      if (!attack) { setAttackQuestion(null); return; }
      setAttackProgress(attack.progress);
      const nextId = attack.questionIds?.[attack.progress];
      if (nextId != null) setAttackQuestion(MATH_TASKS[nextId]); else setAttackQuestion(null);
    } catch (e) { setNotice(e instanceof Error ? e.message : "Challenge failed."); setAttackQuestion(null); }
  };
  const startMatch = async () => { try { await api("start"); setScreen("game"); } catch (e) { setNotice(e instanceof Error ? e.message : "Could not start the match."); } };
  const changeSetting = async (key: "impostors" | "attackWindow", value: number) => { if (!room) return; try { const res = await fetch(`/api/rooms/${room.code}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ playerId, action: "settings", [key]: value }) }); const d = await res.json(); if (!res.ok) throw new Error(d.error); setRoom(d.room); } catch (e) { setNotice(e instanceof Error ? e.message : "Could not update settings."); } };

  if (screen === "home") return <main className="home-screen">
    <header className="brand"><span className="brand-mark">M</span><span>POLY<span className="brand-light">CREW</span></span><span className="season">MATHS MISSION · 06</span></header>
    <section className="home-hero"><div className="hero-copy"><div className="eyebrow"><i/> CHAPTER-BASED MATHS ADVENTURE</div><h1>Repair the ship.<br/><em>Master the maths.</em></h1><p>Explore the Arc, solve polynomial challenges and keep your crew on course.</p><div className="chapter-box"><label htmlFor="chapter">CHOOSE A CHAPTER</label><select id="chapter" value={chapter} onChange={(e) => setChapter(Number(e.target.value))}>{chapters.map((name, i) => <option key={name} value={i + 1} disabled={i + 1 !== 6}>CHAPTER {String(i + 1).padStart(2, "0")} · {name.toUpperCase()}{i + 1 !== 6 ? " · ADD BOOK PAGES TO UNLOCK" : ""}</option>)}</select>{chapter !== 6 && <small>Chapter 6 is ready. Add clear chapter pages to build accurate lessons for another topic.</small>}</div><div className="mode-switch"><button className={mode === "learn" ? "mode selected" : "mode"} onClick={() => setMode("learn")}><span>✦</span><b>LEARN</b><small>Guided walkthroughs</small></button><button className={mode === "revise" ? "mode selected" : "mode"} onClick={() => setMode("revise")}><span>↻</span><b>REVISE</b><small>Recall and practise</small></button></div><button className="primary wide" onClick={startSingle}>START SOLO MISSION <span>→</span></button><button className="secondary wide" onClick={() => { setMultiplayer(true); setScreen("lobby"); }}>PLAY WITH A ROOM CODE <span>⌁</span></button></div>
      <div className="hero-scene"><div className="orbit orbit-a"/><div className="orbit orbit-b"/><div className="star s1">✦</div><div className="star s2">✧</div><div className="star s3">·</div><div className="ship-window"><div className="crew-figure"><div className="crew-glass"/><div className="crew-pack"/></div></div><div className="scene-card"><b>THE ARC</b><span>14 stations · 1 mission</span></div></div>
    </section><footer className="home-foot"><span>✦ POLYNOMIAL MULTIPLICATION</span><span>WASD / ARROW KEYS TO MOVE</span><span>BUILT FOR CURIOUS MINDS</span></footer>
  </main>;

  if (screen === "lobby" && !room) return <main className="lobby-screen"><header className="brand"><button className="back-button" onClick={() => { setScreen("home"); setNotice(""); }}>← BACK</button><span className="brand-mark">M</span><span>POLY<span className="brand-light">CREW</span></span><span className="season">MULTIPLAYER LOBBY</span></header><section className="lobby-card"><div><div className="eyebrow"><i/> CREATE OR JOIN A CREW</div><h1>Meet at the airlock.</h1><p>Choose a name, create a room or enter your crew’s code.</p><label className="field-label" htmlFor="name">CREWMATE NAME</label><input id="name" maxLength={16} value={playerName} onChange={(e) => setPlayerName(e.target.value)} placeholder="Your name"/><div className="field-row"><div><label className="field-label" htmlFor="impostors">IMPOSTORS</label><select id="impostors" value={impostors} onChange={(e) => setImpostors(Number(e.target.value))}>{[1,2,3].map((n) => <option key={n}>{n}</option>)}</select></div><div><label className="field-label" htmlFor="window">ATTACK SOLVE TIME</label><select id="window" value={attackWindow} onChange={(e) => setAttackWindow(Number(e.target.value))}>{[30,45,60,90,120].map((n) => <option key={n} value={n}>{n} seconds</option>)}</select></div></div><button className="primary wide" onClick={createRoom}>CREATE ROOM <span>＋</span></button><div className="join-row"><input aria-label="Room code" maxLength={6} value={roomCode} onChange={(e) => setRoomCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ""))} placeholder="ROOM CODE"/><button className="secondary" disabled={roomCode.length !== 6} onClick={joinRoom}>JOIN ROOM</button></div>{notice && <p className="notice">{notice}</p>}</div><aside className="lobby-aside"><div className="lobby-seal">✦</div><h2>One crew.<br/>One equation<br/>at a time.</h2><p>Each crewmate gets a private role. Solve tasks together, or for impostors: solve three equations to unlock a tag.</p><div className="lobby-rule">WRONG ANSWER OR TIME OUT <b>→</b> IMPOSTOR EJECTED</div></aside></section><footer className="home-foot"><span>ROOM CODES ARE SIX CHARACTERS</span><span>2–10 PLAYERS</span><span>CHAPTER 06 · POLYNOMIALS</span></footer></main>;

  if (screen === "lobby" && room) return <main className="lobby-screen"><header className="brand"><button className="back-button" onClick={() => { setRoom(null); setScreen("home"); }}>← EXIT</button><span className="brand-mark">M</span><span>POLY<span className="brand-light">CREW</span></span><span className="season">WAITING ROOM</span></header><section className="lobby-card room-lobby"><div><div className="eyebrow"><i/> ROOM CODE</div><h1 className="room-code">{room.code}</h1><p>Share this code with your crew. Their names will appear here when they join.</p><div className="roster-grid">{room.players.map((p) => <div className="roster-player" key={p.id}><i style={{ background: colors[p.color] }}/><b>{p.name}</b><small>{p.id === room.hostId ? "HOST" : "READY"}</small></div>)}</div>{playerId === room.hostId ? <><div className="field-row"><div><label className="field-label" htmlFor="lobby-impostors">IMPOSTORS</label><select id="lobby-impostors" value={room.settings.impostors} onChange={(e) => changeSetting("impostors", Number(e.target.value))}>{[1,2,3].map((n) => <option key={n}>{n}</option>)}</select></div><div><label className="field-label" htmlFor="lobby-window">ATTACK SOLVE TIME</label><select id="lobby-window" value={room.settings.attackWindow} onChange={(e) => changeSetting("attackWindow", Number(e.target.value))}>{[30,45,60,90,120].map((n) => <option key={n} value={n}>{n} seconds</option>)}</select></div></div><button className="primary wide" disabled={room.players.length < room.settings.impostors + 2} onClick={startMatch}>START MISSION <span>→</span></button>{room.players.length < room.settings.impostors + 2 && <small className="muted">Need at least {room.settings.impostors + 2} players for this setting.</small>}</> : <div className="waiting-chip">⌁ WAITING FOR THE HOST TO START</div>}{notice && <p className="notice">{notice}</p>}</div><aside className="lobby-aside"><div className="lobby-seal">✦</div><h2>Prepare your<br/>crew, {playerName}.</h2><p>When the host starts the mission, roles are assigned privately. Crew solve stations; impostors solve three equations to tag.</p><div className="lobby-rule">WRONG ANSWER OR TIME OUT <b>→</b> IMPOSTOR EJECTED</div></aside></section><footer className="home-foot"><span>ROOM CODES ARE SIX CHARACTERS</span><span>{room.players.length} PLAYERS CONNECTED</span><span>CHAPTER 06 · POLYNOMIALS</span></footer></main>;
  const online = multiplayer && room;
  const taskDone = (id: number) => online ? room?.completedTasks.includes(id) : completed.includes(id);
  const player = online ? me : null;
  const cameraX = online && player ? player.x / 12 : playerPos.x;
  const cameraY = online && player ? player.y / 7 : playerPos.y;
  const progress = online ? room.completedTasks.length : completed.length;

  return <main className="game-screen">
    <header className="game-top"><button className="game-logo" onClick={() => { setScreen("home"); setRoom(null); }}>M <span>POLYCREW</span></button><div className="top-chapter"><small>CHAPTER 06</small><b>MULTIPLICATION OF POLYNOMIALS</b></div><div className="top-progress"><span>STATIONS RESTORED</span><b>{progress}<i>/14</i></b><div className="progress-track"><i style={{ width: `${(progress / 14) * 100}%` }}/></div></div><button className="exit-button" onClick={() => { setScreen("home"); setRoom(null); }}>EXIT</button></header>
    <div className="game-layout"><aside className="task-panel"><div className="panel-head"><span>✦ TASKS</span><span>{progress}/14</span></div><div className="task-progress-line"><i style={{ width: `${(progress / 14) * 100}%` }}/></div><div className="task-list">{MATH_TASKS.map((t) => <button key={t.id} className={`task-entry ${taskDone(t.id) ? "done" : ""}`} onClick={() => !taskDone(t.id) && openTask(t)}><span className="task-glyph">{taskDone(t.id) ? "✓" : t.type === "wires" ? "⌁" : t.type === "cctv" ? "▣" : t.type === "upload" ? "⇧" : "⌖"}</span><span><b>{t.room}</b><small>{t.title}</small></span><i>{taskDone(t.id) ? "DONE" : "OPEN"}</i></button>)}</div><div className="guide-note"><span>✦</span><div><b>{mode === "learn" ? "LEARN MODE" : "REVISION MODE"}</b><small>{mode === "learn" ? "Guides appear before each task." : "Try it first; hints are available."}</small></div></div></aside>
    <section className="world-wrap"><div className="world-hud"><span>THE ARC <i>·</i> ORBITAL RESEARCH VESSEL</span>{online && <span>ROOM <b>{room.code}</b></span>}<span>{online ? (player?.role === "impostor" ? "IMPOSTOR" : "CREW") : "SOLO MISSION"}</span></div><div className="world-viewport"><div className="world-map" style={{ transform: `translate(calc(50% - ${cameraX}%), calc(50% - ${cameraY}%)) scale(1.38)` }}><div className="corridor corridor-h"/><div className="corridor corridor-v"/><div className="corridor corridor-v2"/>{["ORBITAL LAB","SIGNAL NEST","BIO DOME","ASTRA LENS","ARCHIVE","CREW GALLEY","POWER CORE","FABRICATOR","MED BAY","CARGO HOLD","AQUA WORKS","OBSERVATORY","ENGINE BAY","LAUNCH DECK"].map((roomName, i) => <div key={roomName} className={`map-room r${i}`}><span>{roomName}</span><i>{i % 4 === 0 ? "⌁" : i % 4 === 1 ? "▣" : i % 4 === 2 ? "⇧" : "⌖"}</i></div>)}{Array.from({ length: 9 }, (_, i) => <span key={i} className={`map-star star-${i}`}>✦</span>)}
      {!online && <div className="avatar" style={{ left: `${playerPos.x}%`, top: `${playerPos.y}%` }}><div className="avatar-glass"/><div className="avatar-pack"/><small>YOU</small></div>}
      {online && room.players.filter((p) => p.alive).map((p) => <div key={p.id} className={`avatar ${p.id === playerId ? "self" : "other"}`} style={{ left: `${p.x / 12}%`, top: `${p.y / 7}%`, background: colors[p.color % colors.length] }}><div className="avatar-glass"/><div className="avatar-pack"/><small>{p.id === playerId ? "YOU" : p.name}</small></div>)}
    </div></div><div className="world-bottom"><div className="map-mini"><div className="mini-dot" style={{ left: `${playerPos.x}%`, top: `${playerPos.y}%` }}/><span>SHIP MAP</span></div><div className="move-pad"><button onPointerDown={() => keys.current.add("arrowup")} onPointerUp={() => keys.current.delete("arrowup")}>↑</button><div><button onPointerDown={() => keys.current.add("arrowleft")} onPointerUp={() => keys.current.delete("arrowleft")}>←</button><button onPointerDown={() => keys.current.add("arrowdown")} onPointerUp={() => keys.current.delete("arrowdown")}>↓</button><button onPointerDown={() => keys.current.add("arrowright")} onPointerUp={() => keys.current.delete("arrowright")}>→</button></div></div><div className="hint-chip">WASD / ARROWS <span>MOVE</span></div>{online && player?.role === "impostor" && <button className="danger-button" onClick={startAttack}>SOLVE TO TAG <span>⚡</span></button>}</div></section>
    <aside className="crew-panel"><div className="panel-head"><span>✦ CREW</span><span>{online ? room.players.length : 1}</span></div><div className="crew-card"><div className="crew-avatar"/><div><b>{playerName}</b><small>{online ? player?.role?.toUpperCase() : "SOLO EXPLORER"}</small></div></div>{online && room.players.map((p) => <div className="crew-row" key={p.id}><i style={{ background: colors[p.color] }}/><span>{p.name}{p.id === room.hostId && <small>HOST</small>}</span><b>{p.alive ? "IN" : "OUT"}</b></div>)}{online && player?.role === "impostor" && room.attack?.ready && <div className="tag-box"><b>CHALLENGE PASSED</b><small>Select a crew member to tag</small>{aliveCrew.filter((p) => p.role !== "impostor").map((p) => <button key={p.id} onClick={() => setSelectedTarget(p.id)} className={selectedTarget === p.id ? "selected-target" : ""}>{p.name}</button>)}<button className="danger-button" disabled={!selectedTarget} onClick={() => api("tag", { targetId: selectedTarget }).then(() => setSelectedTarget(""))}>TAG SELECTED CREW</button></div>}<div className="crew-tip"><b>MISSION TIP</b><p>Multiply every term in the first bracket by every term in the second, then collect like terms.</p></div>{notice && <div className="notice mini-notice">{notice}</div>}</aside></div>
    {online && (room.phase === "crew-win" || room.phase === "impostor-win") && <div className="result-overlay"><div className="result-card"><span>✦</span><small>THE ARC · MATCH COMPLETE</small><h2>{room.phase === "crew-win" ? "CREW WINS!" : "IMPOSTORS WIN!"}</h2><p>{room.phase === "crew-win" ? "All equations solved and the ship is restored." : "The impostors outnumbered the crew."}</p><button className="primary" onClick={() => { setRoom(null); setScreen("home"); }}>BACK TO MENU</button></div></div>}
    {isWin && !online && <div className="result-overlay"><div className="result-card"><span>✦</span><small>THE ARC · MISSION COMPLETE</small><h2>YOU WIN!</h2><p>Every station is restored. You mastered polynomial multiplication.</p><button className="primary" onClick={() => { setScreen("home"); setCompleted([]); }}>PLAY AGAIN</button></div></div>}
    {activeTask && <div className="modal-scrim"><section className="task-modal"><header><span className="task-kicker">{activeTask.room} · STATION {String(activeTask.id + 1).padStart(2, "0")}</span><button aria-label="Close task" onClick={() => setActiveTask(null)}>×</button></header><div className="task-modal-body"><div className="task-icon">{activeTask.type === "wires" ? "⌁" : activeTask.type === "cctv" ? "▣" : activeTask.type === "upload" ? "⇧" : "⌖"}</div><h2>{activeTask.title}</h2><p className="task-instruction">{activeTask.type === "wires" ? "Connect the equation to its expanded form." : activeTask.type === "cctv" ? "Restore the feed by solving the polynomial." : activeTask.type === "upload" ? "Enter the correct formula to upload the sequence." : "Calibrate the station by expanding the brackets."}</p>{mode === "learn" && lessonStep < 2 ? <div className="walkthrough"><div className="walk-step">GUIDED WALKTHROUGH · STEP {lessonStep + 1} OF 2</div><div className="equation-display">{lessonStep === 0 ? activeTask.equation : activeTask.partials.join(" + ").replaceAll("+ −", "− ")}</div><p>{lessonStep === 0 ? "Multiply each term in the first bracket by each term in the second." : activeTask.steps}</p><div className="walk-progress"><i style={{ width: `${(lessonStep + 1) * 50}%` }}/></div><button className="primary" onClick={() => setLessonStep(lessonStep + 1)}>{lessonStep === 0 ? "SHOW THE WORKING" : "I'M READY TO SOLVE"} <span>→</span></button></div> : <><div className="equation-display question-equation">{activeTask.equation} <span>→ ?</span></div>{mode === "revise" && lessonStep === 0 && <button className="text-hint" onClick={() => setLessonStep(1)}>Show a hint</button>}{mode === "revise" && lessonStep > 0 && <p className="hint-line">HINT: {activeTask.hint}</p>}<div className="answer-wires">{activeTask.choices.map((choice, i) => <button key={choice} className="answer-choice" onClick={() => submitAnswer(activeTask, choice)}><i className={`wire wire-${i}`}/><span>{choice}</span><b>↗</b></button>)}</div>{answerMessage && <div className={`answer-message ${wrong ? "incorrect" : "correct"}`}>{answerMessage}{wrong && <small>{activeTask.steps}</small>}</div>}{mode === "learn" && <details className="full-solution"><summary>See the full explanation</summary><p>{activeTask.steps}</p></details>}</>}</div></section></div>}
    {attackQuestion && <div className="modal-scrim"><section className="task-modal attack-modal"><header><span className="task-kicker">IMPOSTOR CHALLENGE · {attackProgress + 1} OF 3</span><b className="attack-clock">{attackRemain}s</b></header><div className="task-modal-body"><div className="eyebrow"><i/> SOLVE ALL THREE TO UNLOCK A TAG</div><h2>Quick calculation.</h2><div className="equation-display question-equation">{attackQuestion.equation} = ?</div><div className="answer-wires">{attackQuestion.choices.map((choice) => <button key={choice} className="answer-choice" onClick={() => answerAttack(choice)}><i className="wire wire-1"/><span>{choice}</span><b>↗</b></button>)}</div><div className="walk-progress"><i style={{ width: `${((attackProgress) / 3) * 100}%` }}/></div></div></section></div>}
  </main>;
}
