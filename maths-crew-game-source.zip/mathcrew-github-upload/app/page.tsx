import { CrewGame } from "./play";

export default function Home() {
  return <CrewGame />;
}
