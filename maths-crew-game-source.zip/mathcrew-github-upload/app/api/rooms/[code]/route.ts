import { applyRoomAction, changeRoom, readRoom, RoomError } from "../../../../lib/rooms";

type Context = { params: Promise<{ code: string }> };

function forPlayer(room: Awaited<ReturnType<typeof readRoom>>, playerId: string) {
  const me = room.players.find((p) => p.id === playerId);
  return {
    ...room,
    players: room.players.map((p) => ({ ...p, role: p.id === playerId || me?.role === "impostor" ? p.role : "unknown" })),
    attack: room.attack && room.attack.playerId === playerId
      ? room.attack
      : room.attack
        ? { playerId: room.attack.playerId, progress: room.attack.progress, ready: room.attack.ready, deadline: room.attack.deadline }
        : null,
  };
}

export async function GET(request: Request, context: Context) {
  try {
    const { code } = await context.params;
    const playerId = new URL(request.url).searchParams.get("playerId") || "";
    const room = await readRoom(code);
    const me = room.players.find((p) => p.id === playerId);
    if (!me) throw new RoomError("Join this room first.", 403);
    const visible = forPlayer(room, playerId);
    return Response.json({ room: visible }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    const e = error instanceof RoomError ? error : new RoomError("Room service is unavailable.", 503);
    return Response.json({ error: e.message }, { status: e.status });
  }
}

export async function POST(request: Request, context: Context) {
  try {
    const { code } = await context.params;
    const body = (await request.json()) as Record<string, unknown>;
    const playerId = String(body.playerId || body.id || "");
    const room = await changeRoom(code, (state) => applyRoomAction(state, playerId, body));
    return Response.json({ room: forPlayer(room, playerId) }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    const e = error instanceof RoomError ? error : new RoomError("Room service is unavailable. Try again in a moment.", 503);
    return Response.json({ error: e.message }, { status: e.status });
  }
}
