import { createRoom, RoomError } from "../../../lib/rooms";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { id?: string; name?: string; impostors?: number; attackWindow?: number; map?: string };
    if (!body.id) throw new RoomError("Player id is required.");
    const room = await createRoom({ id: body.id, name: body.name || "Crewmate", impostors: Number(body.impostors), attackWindow: Number(body.attackWindow), map: body.map || "The Arc" });
    return Response.json({ room }, { status: 201 });
  } catch (error) {
    const e = error instanceof RoomError ? error : new RoomError("Room service is unavailable. Try again in a moment.", 503);
    return Response.json({ error: e.message }, { status: e.status });
  }
}
